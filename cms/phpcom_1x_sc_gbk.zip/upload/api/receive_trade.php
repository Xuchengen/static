<?php

/**
 * Copyright (c) 2010-2011  phpcom.cn - All rights reserved.
 * Our Website : www.phpcom.cn www.phpcom.net www.cnxinyun.com
 * Description : This software is the proprietary information of phpcom.cn.
 * This File   : receive_trade.php    2012-1-7
 */
define('CURRENT_SCRIPT', 'api');
require '../src/inc/common.php';

include loadlibfile('alipay', 'api');
?>
