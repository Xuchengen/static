function textareaResize(obj, op){
	if(op) {
		if(obj.style.position == 'absolute') {
			obj.style.position = '';
			obj.style.width = '';
			obj.parentNode.style.height = '';
			obj.style.height = '';
			obj.parentNode.style.verticalAlign = 'middle';
		} else {
			obj.parentNode.style.height = obj.parentNode.offsetHeight + 'px';
			obj.style.width = phpcom.isIE6 ? '650px' : '75%';
			obj.style.position = 'absolute';
			obj.parentNode.style.verticalAlign = 'top';
		}
	}
}

function toRefresh(e){
	window.location.reload();
}

function toRedirect(url) {
	window.location.replace(url);
}

function formdown(){
	if(event.keyCode == 13){ 
		return false; 
	}else{
		return true;
	}
}

function changeRunSystem(s){
	if(!s) return false;
	var runsystem = $('runsystemtext');
	var curvalue = runsystem.value;
	if(curvalue == ''){
		runsystem.value = s;
	}else{
		if(curvalue.indexOf(s) == -1){
			runsystem.value += ', '+s;
		}
	}
	runsystem.focus();
	return false;
}

function make_authkey(name, len) {
	var c = "0123456789QWERTYUIOPASDFGHJKLZXCVBNMqwertyuioplkjhgfdsazxcvbnm";
	var s = "";
	var obj = $(name);
	len = isUndefined(len) ? 32 : len;
	if(obj && obj.value == ''){
		for (var i = 0; i < len; i++) {
			s += c.charAt(Math.ceil(Math.random() * 100000000) % c.length);
		}
		obj.value = s;
	}
}

function checkAll(type, form, value, checkall) {
	var checkall = checkall ? checkall : 'chkall';
	for(var i = 0; i < form.elements.length; i++) {
		var e = form.elements[i];
		if(type == 'option' && e.type == 'radio' && e.value == value && e.disabled != true) {
			e.checked = true;
		} else if(type == 'value' && e.type == 'checkbox' && e.getAttribute('chkvalue') == value) {
			e.checked = form.elements[checkall].checked;
		} else if(type == 'prefix' && e.name && e.name != checkall && (!value || (value && e.name.match(value)))) {
			e.checked = form.elements[checkall].checked;
		}
	}
}

function toggleFormTarget(obj, defvalue) {
	defvalue = undef(defvalue, '_framethread');
	if(isUndefined(obj.form.target)) return;
	if(obj.form.target == '_blank'){
		obj.form.target = defvalue;
	}else{
		obj.form.target = '_blank';
	}
}

function alterStyle(obj, tn){
	tn = isUndefined(tn) ? 'li' : tn;
	function clearAltStyle(obj, tn) {
		var node, i;
		node = obj.parentNode.getElementsByTagName(tn);
		for(i=0; i < node.length; i++){
			node[i].className = '';
		}
	}
	var isIE = phpcom.isIE;
	var input, nodelist, i, m, tagName;
	m = 0;
	nodelist = obj.getElementsByTagName(tn);
	for(i=0; i < nodelist.length; i++){
		nodelist[i].onclick = function(e) {
			tagName = isIE ? event.srcElement.tagName : e.target.tagName;
			if(m) return;
			m = 1;
			input = this.getElementsByTagName('input')[0];
			if(input.getAttribute('type') == 'checkbox' || input.getAttribute('type') == 'radio') {
				if(input.getAttribute('type') == 'radio') {
					clearAltStyle(this, tn);
				}

				if(isIE || tagName != 'INPUT' && input.onclick) {
					input.click();
				}
				if(this.className != 'checked') {
					this.className = 'checked';
					input.checked = true;
				} else {
					this.className = '';
					input.checked = false;
				}
			}
		}
		nodelist[i].onmouseup = function(e) {
			m = 0;
		}
	}
}

function toggle_display(id){
	var el = $('groupbody_' + id);
	if (el == null) return;
	if (el.style.display == 'none') {
		el.style.display = '';
		$('toggle_' + id).className = 'toggle hide-icon';
	} else {
		el.style.display = 'none';
		$('toggle_' + id).className = 'toggle show-icon';
	}
}

function toggle_all(m){
	var tbodys = $("adminform").getElementsByTagName('tbody');
	for(var i = 0; i < tbodys.length; i++) {
		var re = /^groupbody_(\d+)$/;
		var matches = re.exec(tbodys[i].id);
		if(matches != null) {
			if(m == 'hide') {
				tbodys[i].style.display = 'none';
				$('toggle_' + matches[1]).className = 'toggle show-icon';
			}else{
				tbodys[i].style.display = '';
				$('toggle_' + matches[1]).className = 'toggle hide-icon';
			}
		}
	}
}

function toggleDisplay(id, m){
	if(m == 'hide'){
		$(id).style.display = 'none';
	}else{
		$(id).style.display = '';
	}
}

function hideDisplay(id){
	$(id).style.display = $(id).style.display == '' ? 'none' : '';
}

function showDescrLength(id){
	var whichEl = $(id);
	if (whichEl!=null) {
		alert ("��ǰ��������Ϊ " + whichEl.value.length + " �ֽڣ�");
	}else{
		alert ("��ǰ��������Ϊ 0 �ֽڣ�");
	}
}

function changeSelectColor(o){
	var color = o.options[o.selectedIndex].text;
	if(o.value == 0){
		o.style.color = 'black';
		o.style.backgroundColor = 'white';
	}else{
		o.style.color = color;
		o.style.backgroundColor = color;
	}
}

function toggle_highlightstyle(o, v, name) {
	name = isUndefined(name) ? 'highlight_style' : name;
	var obj = $(name);
	var h = parseInt(obj.value);
	if (o.className.match(/ btncnt/i)) {
		if(h < 4){
			obj.value = 0;
		}else if(h == 7){
			obj.value = 7 - v;
		}else{
			var n = h - v - 1;
			obj.value = n < 0 ? 0 : n;
		}
		o.className = o.className.replace(/ btncnt/, '');
	}else{
		if(h == 0){
			obj.value = v;
		}else{
			var n = h + v + 1;
			obj.value = n > 7 ? 7 : n;
		}
		o.className += ' btncnt';
	}
} 

function toggle_anchor(obj,id) {
	var navs = $('nav_tabs').getElementsByTagName('li');
	for(var i = 0; i < navs.length; i++) {
		if(navs[i].id.substr(0, 4) == 'nav_' && navs[i].id != obj.id) {
			if($(navs[i].id.substr(4))) {
				navs[i].className = '';
				$(navs[i].id.substr(4)).style.display = 'none';
				if($(navs[i].id.substr(4) + '_tips')) $(navs[i].id.substr(4) + '_tips').style.display = 'none';
			}
		}
	}
	obj.className = 'active';
	currentAnchor = obj.id.substr(4);
	$(currentAnchor).style.display = '';
	if($(currentAnchor + '_tips')) $(currentAnchor + '_tips').style.display = '';
	if($(id)){
		$(id).innerHTML = obj.title;
	}
}
function toggle_tabstrip(name){
	var btn = $('btn_'+name);
}
function show_style(){
	var url='static/admin/setstyle.htm';
	return openDialog('static/admin/setstyle.htm','window','���÷��',290,240,0);
}

function cancel_style(){
	$('title_style').value='';
	$('demo_style').innerHTML='<span style="background:#ffffff;font-size:12px">���ñ�����ʽ ABC123</span>';
}

function previewColorValue(obj) {
	var s = $(obj + '_v').value;
	$(obj).style.backgroundColor = s;
}

function activeTabs(id){
	var navobj = parent.$("tabs");
	if(navobj){
		var navlst = navobj.getElementsByTagName("a");
		if(navlst){
			for(var i= 0,len = navlst.length;i<len;++i){
				if(navlst[i].clssName !==""){
					navlst[i].className = "";
				}
			}
			var obj = parent.$('tabs_'+id);
			if(obj){
				obj.className = "active";
				obj.blur();
			}
		}
	}
}

function addvoteOption(){
	var totalSpanNum = $('voteoptions').getElementsByTagName('span');
	if (totalSpanNum.length >= 300) return false;
	var source = $('basevoteoption');
	var target = source.cloneNode(true);
	var aTag = target.getElementsByTagName('a');
	aTag[0].style.display = '';
	var input = target.getElementsByTagName('input');
	input[0].value = '';
	input[1].value = '0';
	input[2].value = '0';
	target.removeAttribute('id');
	$('voteoptions').insertBefore(target, $('addvote_button'));
}

function delvoteOption(obj) {
	obj.parentNode.parentNode.removeChild(obj.parentNode);
}

function addPlayAddress(){
	var address = $('play_address_body').firstChild;
	var index = address.getElementsByTagName('select')[0].selectedIndex; 
	var target = address.cloneNode(true);
	target.getElementsByTagName('textarea')[0].value = '';
	target.getElementsByTagName('textarea')[0].name = 'addressnew[]';
	target.getElementsByTagName('select')[0].selectedIndex = index;
	target.getElementsByTagName('select')[0].name = 'playernew[]';
	if(target.getElementsByTagName('input')[0]){
		target.getElementsByTagName('input')[0].value = '';
		target.getElementsByTagName('input')[0].name = 'captionnew[]';
	}
	$('play_address_add').insertBefore(target,null);
}

function insert_tags(){
	return openDialog('?m=tags&action=insert','tags','����Tags',820,460);
}

function showTopicMenu(obj, url){
	var id = obj.id;
	var ajax = ajaxObject();
	var timenow	= new Date().getTime();
	url	+= (url.indexOf("?") >= 0) ? "&t=" + timenow : "?t=" + timenow;
	url = url.replace(/\&inajax\=1/g, '')+'&inajax=1';
	ajax.get(url,function(s){
		$(id+'_menu').innerHTML = s;
		showMenu({'ctrlid':id});
	});
}

function threadModify(channelid, operation) {
	var checked = 0;
	var operation = !operation ? '' : operation;
	for(var i = 0; i < $('adminform').elements.length; i++) {
		if($('adminform').elements[i].name.match('delete') && $('adminform').elements[i].checked) {
			checked = 1;
			break;
		}
	}
	if(!checked) {
		alert('��ѡ����Ҫ���������⣡');
	} else {
		$('adminform').channelid.value = channelid;
		$('adminform').action.value = operation;
		//showWindow('mods', 'moderate', 'post');
		styleWindow('?m=ajax_setstyle','floatctrl_drag');
	}
}

var rowtypedata = ['&nbsp;','<input name="newquestion[]" type="text" size="50" class="input">','<input name="newanswer[]" type="text" size="35" class="input">'];

function addrow(obj, type) {
	var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
	var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
	var typedata = rowtypedata;
	row.className = 'tr-1';
	for(var i = 0; i <= typedata.length - 1; i++) {
		var cell = row.insertCell(i);
		var data = typedata[i];
		cell.className = 'tablerow1';
		cell.innerHTML = data;
	}
}

function deleterow(obj) {
	var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
	var tr = obj.parentNode.parentNode.parentNode;
	table.deleteRow(tr.rowIndex);
}

function openTopicWindow() {
	return openDialog('?m=special&action=select', 'special', 'ѡ��ר��',820,460);
}

function openQuickEdit(tid, chanid) {
	return openDialog('?m=soft&action=quickedit&tid='+tid+'&chanid='+chanid, 'quickedit', '���ٱ༭', 620, 460);
}

function openThreadClassWindow(chanid) {
	var catid = $('catid').value;
	return openDialog('?m=category&action=select&chanid='+chanid+'&catid='+catid, 'threadclass', 'ѡ�����',620,360);
}

function selectThreadClass(obj) {
	obj.size = obj.options.length +1;
	obj.style.position = 'absolute';
	obj.style.height = '';
	obj.style.top = '-2px';
	obj.style.zIndex = 999;
}

function resetThreadClass(obj) {
	obj.style.height = '21px';
	obj.style.position = '';
	obj.size = 1;
}

function showSubcategory(obj, showid, chanid) {
	var ajax = ajaxObject();
	var timenow	= new Date().getTime();
	var url = "apps/ajax.php?action=category&chanid="+chanid+"&rootid=" + obj.value;
	url	+= (url.indexOf("?") >= 0) ? "&t=" + timenow : "?t=" + timenow;
	url = url.replace(/\&inajax\=1/g, '')+'&inajax=1';
	
	ajax.get(url,function(s){
		var txt=''
		if(!isUndefined(showid) && $(showid)){
			txt = parsescript(s);
			if(txt != ''){
				$(showid).innerHTML = txt;
				$(showid).style.display = '';
			}else{
				$(showid).innerHTML = '';
				$(showid).style.display = 'none';
			}
		}else if(s != ''){
			txt = parsescript(s);
		}
	});
	return false;
}

function initTopicSelect(name){
	var obj = parent.$(name);
	if (obj && obj.value.length>0){
		$('selectedstring').value = obj.value;
		var arr = obj.value.split(',');
		for (var i=0; i<arr.length; i++){
			var input = $('checkbox_'+arr[i]);
			if(input){
				input.checked = true;
				input.parentNode.parentNode.className = 'item checked';
			}
		}
	}
}

function topicalAdd(obj, name) {
	var str = obj.value;
	var topic = parent.$(name);
	var tObj = $('selectedstring');
	
	if (topic && topic.value.length>0){
		var tids = '';
		
		var arr=topic.value.split(',');
		
		for (var i=0;i<arr.length;i++){
			if(arr[i] != '' && arr[i] != str){
				tids += arr[i] + ',';
			}
		}
		
		if(obj.checked) tids += str;
		topic.value = tids;
		tObj.value = tids;
		
	}else{
		if(obj.checked){
			topic.value = str;
			tObj.value = str;
		}else{
			topic.value = '';
			tObj.value = '';
		}
	}
	var item = obj.parentNode.parentNode;
    item.className = item.className == 'item' ? 'item checked' : 'item';
}

function simpleUploadWindow(obj){

}

function imageUploadWindow(obj){
	//alert(obj.parentNode.firstChild.value);
	alert(obj.value);
}

function uploadingWindow(type, dirname, chanid, tid, tmpid){
	dirname = undef(dirname, 'image');
	chanid = undef(chanid, 0);
	tid = undef(tid, 0);
	showWindow('apps/ajax.php?action=uploading&type=' + type + '&dirname=' + dirname + '&chanid=' + chanid + '&tid=' + tid, 'uploading');
}

function uploadingSubmit(form, inputbyid){
	form = $(form);
	if(form){
		if(!isUndefined(inputbyid) && $(inputbyid)){
			var frmOptionId = inputbyid + '_extend';
			if($(frmOptionId)){
				form.removeChild($(frmOptionId));
			}
			var source = $(inputbyid);
			var target = source.cloneNode(true);
			target.id = frmOptionId;
			target.style.display = 'none';
			form.appendChild(target);
		}
		form.submit();
	}
}

function uploadingImageDelete(inputbyid){
	if(!isUndefined(inputbyid) && $(inputbyid)){
		$(inputbyid).value = '-1';
		alert('�ύ��ɺ�����Զ�ɾ����ͼƬ');
	}
}

function loadUploadingWindow(frm, attid){
	var jsonstr = frm.contentWindow.document.body.innerHTML;
	if(jsonstr == '') return;
	var file = (new Function("return " + jsonstr))();
	if(file.status){
		alert('�ϴ�ʧ��');
	}
	
	if(!isUndefined(attid)){
		if($(attid)){
			$(attid).value = file.attachid;
		}
		if($(attid + '_file')){
			$(attid + '_file').value = file.attachment;
		}
	}else{
		if($('fileurl')){
			$('fileurl').value = file.attachment;
		}
		if($('tmpid')){
			$('tmpid').value = file.attachid;
		}
	}
}
