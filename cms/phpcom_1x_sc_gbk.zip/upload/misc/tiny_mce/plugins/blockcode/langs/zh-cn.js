tinyMCE.addI18n('zh-cn.blockcode',{
	desc : '\u63D2\u5165\u4EE3\u7801'
});