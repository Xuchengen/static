tinyMCE.addI18n('en.blockcode',{
	desc : 'Insert code'
});

