tinyMCE.addI18n('zh-cn.blockcode_dlg',{
title:"\u63D2\u5165\u4EE3\u7801\u7247\u6BB5",
desc:"\u5C06\u590D\u5236(CTRL + C)\u7684\u5185\u5BB9\u7C98\u8D34(CTRL + V)\u5230\u7A97\u53E3\u3002",
code_wordwrap:"\u81EA\u52A8\u6362\u884C",
code_type:"\u63D2\u5165\u8FD0\u884C\u4EE3\u7801"
});