tinyMCE.addI18n('en.remoteupload',{
	desc : 'Save remote image'
});
