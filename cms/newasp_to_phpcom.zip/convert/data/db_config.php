<?php

return array (
  'db' => 
  array (
    'driver' => 'mysql',
    'username' => 'root',
    'password' => '',
    'pconnect' => '0',
    'tablepre' => 'pc_',
    'charset' => 'gbk',
    'dsn' => 
    array (
      'host' => 'localhost',
      'port' => '3306',
      'charset' => 'gbk',
      'dbname' => 'phpcom',
    ),
  ),
  'mssql' => 
  array (
    'driver' => 'odbc',
    'username' => 'sa',
    'password' => '',
    'pconnect' => '0',
    'tablepre' => 'nc_',
    'dsn' => 
    array (
      'Driver' => '{SQL Server}',
      'Server' => '192.168.1.203',
      'Database' => 'newasp',
    ),
  ),
  'mdb' => 
  array (
    'driver' => 'odbc',
    'username' => '',
    'password' => '',
    'pconnect' => '0',
    'tablepre' => 'nc_',
    'dsn' => 
    array (
      'Driver' => '{Microsoft Access Driver (*.mdb)}',
      'Dbq' => 'newasp.mdb',
    ),
  ),
  'table' => 
  array (
    'article' => '1',
    'soft' => '1',
    'first' => 'soft',
  ),
  'charset' => 'gbk',
);
?>