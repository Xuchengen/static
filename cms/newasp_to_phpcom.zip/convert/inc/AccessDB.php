<?php
/**
 * Copyright (c) 2010-2013 PHPcom - All rights reserved.
 * Our Website : www.phpcom.cn www.phpcom.net www.cnxinyun.com
 * Description : This software is the proprietary information of PHPcom.
 * This File   : AccessDB.php  2013-4-4
 */

class AccessDB
{
	public static function table($table, $index = 0)
	{
		$table .= $index ? "_$index" : '';
		return self::getInstance()->tableName($table);
	}
	
	public static function selectdb($dbname)
	{
		return self::getInstance()->selectdb($dbname);
	}
	
	public static function query($sql)
	{
		return self::getInstance()->query($sql);
	}
	
	public static function execQuery($sql, $column_number = null)
	{
		return self::getInstance()->execQuery($sql, $column_number);
	}
	
	public static function exec($sql)
	{
		return self::getInstance()->exec($sql);
	}
	
	public static function lastInsertId($name = null)
	{
		return self::getInstance()->lastInsertId($name);
	}
	
	public static function version()
	{
		return self::getInstance()->version();
	}
	
	public static function quote($string)
	{
		return self::getInstance()->quote($string);
	}
	
	public static function &getInstance() 
	{
		static $db;
		global $db_config;
		if (empty($db)) {
			$db = new PdoDriver($db_config['mdb']);
		}
		return $db;
	}
}
?>