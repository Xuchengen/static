document.write("<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0' width='180' height='220'>");
document.write("  <param name='movie' value='vote/vote.swf'>");
document.write("  <param name='quality' value='high'>");
//document.write("  <param name='wmode' value='transparent'>");
document.write("  <embed src='vote/vote.swf' quality='high' pluginspage='http://www.macromedia.com/go/getflashplayer' type='application/x-shockwave-flash' width='180' height='220'></embed></object>");