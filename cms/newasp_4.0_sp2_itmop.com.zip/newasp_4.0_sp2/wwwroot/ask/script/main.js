document.charset = "GB2312";

function ResumeError() {
	return true;
}
//window.onerror = ResumeError;

var xmlhttp = HttpAXObj();

function HttpAXObj(){
	var xmlhttp = null;
	try{
		xmlhttp= new ActiveXObject('Msxml2.XMLHTTP');
	}catch(e){
		try{
			xmlhttp= new ActiveXObject('Microsoft.XMLHTTP');
		}catch(e){
			try{
				xmlhttp= new XMLHttpRequest();
			}catch(e){
				try{
					xmlhttp= window.createRequest();
				}catch(e){}
			}
		}
	}
	if (xmlhttp) return xmlhttp;
}

function trim(content)
{
	content = content.replace(/(^\s*)|(\s*$)/g, "");
	return content;
}

function isEmpty(s)
{
	return (s==null)||(s.length==0);
}

function searchAnswer(questionTitle)
{		
	var title = trim(questionTitle.value);
	if(isEmpty(title))
	{
		alert('�����롾������⡿�Ĺؼ��֡�');
		questionTitle.select();
		return false;
	}
	return true;
}

function checkIsSearch(){
	var _where = top.document.referrer;
	if ( ! _where ) {return true;}
	if(_where.indexOf("newasp.net")==-1 && _where.indexOf("duote.com")==-1 && _where.indexOf("ok8848.com")==-1){
		return false;
	}else{
		return true;
	}
}

var search_url = '';
var ask_url = '';
var sitePath = "/";

function checkKey(questionTitle, ev)
{
	if(ev.keyCode==13)
	{
		if(searchAnswer(questionTitle))
			window.location.href = search_url + escape(questionTitle.value);
		return false;
	}
	return true;
}
function redirectSearch(questionTitle, isSrch)
{
	if(isSrch==null)
	{
		window.location.href = "http://www.google.cn/search?q=" + escape(questionTitle.value) + "&client=pub-7181357378968076&forid=1&prog=aff&ie=GB2312&oe=GB2312&hl=zh-CN";
	}else{
		if(isSrch)
		{
			if(searchAnswer(questionTitle))
				window.location.href = search_url + escape(questionTitle.value);
				return false;
		}
		else window.location.href = ask_url + escape(questionTitle.value);
	}
}


function getCookie(CookieName) {
	var start = document.cookie.indexOf(CookieName + '=');
	var len = start + CookieName.length + 1;
	if ((!start) && (CookieName != document.cookie.substring(0,CookieName.length)))
		return null;
	if (start == -1)
		return null;
	var end = document.cookie.indexOf(';',len);
	if (end == -1) end = document.cookie.length;
		return unescape(document.cookie.substring(len,end));
}

function setCookie(CookieName,value,expires,path,domain,secure) {
	document.cookie = CookieName + "=" +escape(value) +
	( (expires) ? ";expires=" + expires : "") +
	( (path) ? ";path=" + path : "") + 
	( (domain) ? ";domain=" + domain : "") +
	( (secure) ? ";secure" : "");
}

function deleteCookie(CookieName,path,domain) {
	if (getCookie(CookieName))
		document.cookie =
		CookieName + '=' +
		( (path) ? ';path=' + path : '') +
		( (domain) ? ';domain=' + domain : '') +
		';expires=Thu, 01-Jan-1970 00:00:01 GMT';
}

function setLinkAttributes(switchLinks) {
	if (switchLinks == "true") {
		if (!document.getElementsByTagName) return;
		var anchors = document.getElementsByTagName("a");
			for (var i=0; i<anchors.length; i++) {
			var anchor = anchors[i];
			
			if (anchor.getAttribute("href") && ( anchor.getAttribute("rel") == "external" || anchor.getAttribute("rel") == "nofollow" ) ) {
				anchor.target = "_blank";
			}
		}
	} else {
		if (!document.getElementsByTagName) return;
		var anchors = document.getElementsByTagName("a");
			for (var i=0; i<anchors.length; i++) {
			var anchor = anchors[i];
			
			if (anchor.getAttribute("href") && ( anchor.getAttribute("rel") == "external" || anchor.getAttribute("rel") == "nofollow" ) ) {
				anchor.target = "_self";
			}
		}
	}
}

function toggleLinkAttributes() {
	var ExpireLongTerm = new Date();
	var ExpireLongTermValue = new Date(ExpireLongTerm.getTime()+(1000 * 60 * 60 * 360000));

	var check_tag = document.getElementById('toggleLinks');
	if ( check_tag.checked == true )
	{
		setLinkAttributes("false");
		setCookie("externalLinks","true",ExpireLongTermValue,"/",document.domain);
	} else {
		setLinkAttributes("true");
		deleteCookie("externalLinks","/",document.domain);
	}
}	

function resizeme(srcimg){
	try{
		var aimg=new Image;
		aimg.src=srcimg.src;
		var w=aimg.width;
		var h=aimg.height;
		img=null;
		var r=parseInt(w)/parseInt(h);
		if(w>500){w=500;h=500/r;}
		if(h>800){h=800;w=800*r;}$(srcimg).attr({width:w,height:h});
	}
	catch(e){}
}

function loadAjaxData(strUrl,sid)
{
	var xmlhttp = HttpAXObj();
	try{
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4){
				if(xmlhttp.status==200){
					var response = xmlhttp.responseText;
					if (!sid){
						eval(response);
					}else{
						var innerEl = document.getElementById(sid);
						if(typeof(innerEl)=='object')
						innerEl.innerHTML = response;
					}
				}else{}
			}
		}
		xmlhttp.open("GET",strUrl.replace("&&","&"),true);
		//xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		xmlhttp.send("");
	}catch(e){}
	delete xmlhttp;
}

function onloadAjaxData(strUrl,sid)
{
	var xmlhttp = HttpAXObj();
	try{
		xmlhttp.onreadystatechange=function(){
			if(xmlhttp.readyState==4){
				if(xmlhttp.status==200){
					var response = xmlhttp.responseText;
					//alert(response);
					if (!sid){
						eval(response);
					}else{
						var innerEl = document.getElementById(sid);
						if(typeof(innerEl)=='object')
						innerEl.innerHTML = response;
					}
				}else{}
			}
		}
		xmlhttp.open("GET",strUrl.replace("&&","&"),true);
		xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		xmlhttp.send("");
	}catch(e){}
	delete xmlhttp;
}

function ActiveOnline(classid,s){
	var xmlhttp = HttpAXObj();
	xmlhttp.onreadystatechange=function(){
		if(xmlhttp.readyState==4){
			if(xmlhttp.status==200){
				eval(xmlhttp.responseText);
				if (s){
					var AllOnlie=document.getElementById("allonline");
					if(AllOnlie) AllOnlie.innerHTML=allonline.toString();
				}
			}else{}
		}
	}
	var param="classid="+classid+"&state="+escape(document.title.toString())+"&referer="+escape(document.referrer)+"&url="+document.URL;
	xmlhttp.open("post","script/activeonline.asp",true);	
	xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("Content-Length",param.length); 
	xmlhttp.send(param);
	delete xmlhttp;
}
