/*
 * Thickenbox 1.0 - One Box To Rule Them All.
 * By NewAsp WebEnvoy (http://www.newasp.net)
 * Copyright (C) 2007,2008 NewAsp.Net. All rights reserved.
*/
var Thickenbox = {
	shadowId : null,
	shadowEl : document.createElement('div'),
	overlayId : 'TB_shadowOverlay',
	shadeId : null,
	hidesId : null,
	width : 400,
	height : 300,
	//left : 400,
	//top : 300,
	tb_show : function(id,w,h,src) {
		Thickenbox.height = parseInt(h);
		Thickenbox.width = parseInt(w);
		Thickenbox.shadowEl.id = Thickenbox.overlayId;
		Thickenbox.shadowId = document.getElementById(id);
		document.body.insertBefore(Thickenbox.shadowEl,null);
		Thickenbox.tb_position();
		if (document.getElementById("TB_iframeContent")) document.getElementById("TB_iframeContent").src=src;
		
		document.onkeyup = function(e){ 	
				if (e == null) { // ie
					keycode = event.keyCode;
				} else { // mozilla
					keycode = e.which;
				}
				if(keycode == 27){ // close
					Thickenbox.tb_close();
				}	
			};
	},
	tb_showframe : function(url,caption){
		var strURL=url;
		if(caption==null){caption="";}
		if (!strURL){return;}
		if(strURL.indexOf("?")==-1){return;}
		var queryString = strURL.replace(/^[^\?]+\??/,'');
		var params = tb_parseQuery( queryString );
		var sh,sw;
		sw = (params["sw"]*1) || 650;
		sh = (params["sh"]*1) || 440;

		var shadowFrame = document.createElement('div');
		shadowFrame.id = Thickenbox.overlayId + "_frame";
		shadowFrame.name = Thickenbox.overlayId + "_frame"+Math.round(Math.random()*1000);
		shadowFrame.style.width = sw+"px";
		shadowFrame.style.height = sh+"px";
		document.body.appendChild(shadowFrame);
		//var divhtml = "<div class='titlebg' style='width:100%;' id='TB_windowTitle'>  <img src='images/icons/close.gif' alt='�ر�' class='imgonclick' style='float:right;margin-right:5px;margin-top:5px;' onclick='Thickenbox.tb_close();'/>"+caption+"</div>"
		var divhtml = "<div class='titlebg' style='width:100%;' id='TB_windowTitle'><span title='�ر�' class='TB_close' onclick='Thickenbox.tb_close();'> </span><span class='TB_title'>"+caption+"</span></div>"
		divhtml += "<iframe frameborder='0' hspace='0' src='' id='TB_iframeContent' name='_TB_iframeContent"+Math.round(Math.random()*1000)+"' style='width:"+sw+"px;height:"+(sh-30)+"px;'> </iframe>"
		shadowFrame.innerHTML = divhtml;
		Thickenbox.tb_show(shadowFrame.id,sw,sh,strURL);
	},
	tb_position : function() {
		if (!Thickenbox.shadowId){
			Thickenbox.shadowId = null;
			return;
		}
		document.documentElement.style.overflow='hidden';		//���ع�����
		var de = document.documentElement;
		var w = window.innerWidth || self.innerWidth || (de&&de.clientWidth) || document.body.clientWidth;
		var ch = window.innerHeight || self.innerHeight || (de&&de.clientHeight) || document.body.clientHeight;
		if (self.pageYOffset) {
			var st = self.pageYOffset;
		} else if (document.documentElement && document.documentElement.scrollTop){	 // Explorer 6 Strict
			var st = document.documentElement.scrollTop;
		} else if (document.body) {// all other Explorers
			var st = document.body.scrollTop;
		}
		if (window.innerHeight && window.scrollMaxY) {	
			var sh = window.innerHeight + window.scrollMaxY;
		} else if (document.body.scrollHeight > document.body.offsetHeight){ // all but Explorer Mac
			var sh = document.body.scrollHeight;
		} else { // Explorer Mac...would also work in Explorer 6 Strict, Mozilla and Safari
			var sh = document.body.offsetHeight;
		}
		Thickenbox.shadowEl.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(opacity=60,finishOpacity=100,style=0)';
		Thickenbox.shadowEl.style.height = (sh > ch ? sh : ch) + 'px';
		Thickenbox.shadowEl.style.width = '100%';//w + 'px';
		
		var pos = [], pw;
		pw = Thickenbox.width;
		pos[0] = (w-pw)/2;
		pos[1] = (ch-(Thickenbox.height || 300))/2 + st;
		//window.status="ch:"+ch+"st:"+st+"post[1]:"+pos[1]+"Thickenbox.clientHeight"+Thickenbox.shadowId.clientHeight;
		//document.title="ch:"+ch+"st:"+st+"post[1]:"+pos[1]+"Thickenbox.clientHeight"+Thickenbox.shadowId.clientHeight;
		if (navigator.product && navigator.product == 'Gecko'){
			pw -= 40;
		}
		
		Thickenbox.shadowId.style.width = Thickenbox.width + 'px';
		Thickenbox.shadowId.style.height = Thickenbox.height + 'px';
		Thickenbox.shadowId.style.left = pos[0] + 'px';
		Thickenbox.shadowId.style.top = pos[1] + 'px';
		Thickenbox.shadowEl.style.display = 'block';
		Thickenbox.shadowId.style.display = 'block';
		
		if(!tb_detectMacXFF()){
			Thickenbox.tb_append(w,ch);
		}
		
	},
	tb_append : function(w,h) {
		var shadeEl = document.createElement('div');
		shadeEl.style.visibility = "";
		shadeEl.style.position = "absolute";
		shadeEl.style.left = 0;
		shadeEl.style.top = 0;
		shadeEl.style.width = w+'px';
		shadeEl.style.height = h+'px';
		shadeEl.style.border='0'
		shadeEl.id = 'TB_overlay';
		
		var hidesEl = document.createElement('iframe');
		hidesEl.name = 'TB_hideSelect';
		hidesEl.id = 'TB_hideSelect';
		hidesEl.width = shadeEl.style.width;
		hidesEl.height = shadeEl.style.height;
		hidesEl.style.border='none';

		shadeEl.appendChild(hidesEl);
		document.body.appendChild(shadeEl);
		Thickenbox.shadeId = document.getElementById(shadeEl.id);
		Thickenbox.hidesId = document.getElementById(hidesEl.id);
	},
	tb_close : function(){
		if (Thickenbox.shadowId==null){
			return;
		}
		Thickenbox.tb_remove();
	},
	tb_remove : function() {
		document.documentElement.style.overflow='';		//��ʾ������
		Thickenbox.shadowId.style.display = 'none';
		Thickenbox.shadowEl.style.display = 'none';		
		document.body.removeChild(Thickenbox.shadowId);
		document.body.removeChild(Thickenbox.shadowEl);
		if(!tb_detectMacXFF()){
			Thickenbox.shadeId.style.display = 'none';
			Thickenbox.hidesId.style.display = 'none';
			document.body.removeChild(Thickenbox.shadeId);
			//document.body.removeChild(Thickenbox.hidesId);
		}
		
	}
}

//url�����ָ�
function tb_parseQuery ( query ) {
   var Params = {};
   if ( ! query ) {return Params;}// return empty object
   var Pairs = query.split(/[;&]/);
   for ( var i = 0; i < Pairs.length; i++ ) {
      var KeyVal = Pairs[i].split('=');
      if ( ! KeyVal || KeyVal.length != 2 ) {continue;}
      var key = unescape( KeyVal[0] );
      var val = unescape( KeyVal[1] );
      val = val.replace(/\+/g, ' ');
      Params[key] = val;
   }
   return Params;
}
function tb_getPageSize(){
	var de = document.documentElement;
	var w = window.innerWidth || self.innerWidth || (de&&de.clientWidth) || document.body.clientWidth;
	var h = window.innerHeight || self.innerHeight || (de&&de.clientHeight) || document.body.clientHeight;
	arrayPageSize = [w,h];
	return arrayPageSize;
}
function tb_detectMacXFF() {
  var userAgent = navigator.userAgent.toLowerCase();
  if (userAgent.indexOf('mac') != -1 || userAgent.indexOf('firefox')!=-1 || userAgent.indexOf('opera')!=-1) {
	return true;
  }else{
	return false;
  }
}
function hideAllSelect( switchsel ) { 
	var   selects = document.getElementsByTagName("SELECT");
	if (selects)
	{
		for(var i = 0; i <selects.length;i++) 
		{
			if (switchsel == "true") {
				selects[i].style.visibility = "hidden";
			}else{
				selects[i].style.visibility = "";
			}
		}
	}
} 

//alert(navigator.userAgent.toLowerCase())