var UBBBrowerInfo=new Object();
var sAgent=navigator.userAgent.toLowerCase();
UBBBrowerInfo.IsIE=sAgent.indexOf("msie")!=-1;
UBBBrowerInfo.IsGecko=!UBBBrowerInfo.IsIE;UBBBrowerInfo.IsNetscape=sAgent.indexOf("netscape")!=-1;
if (UBBBrowerInfo.IsIE){
	UBBBrowerInfo.MajorVer=navigator.appVersion.match(/MSIE (.)/)[1];
	UBBBrowerInfo.MinorVer=navigator.appVersion.match(/MSIE .\.(.)/)[1];}
else{
	UBBBrowerInfo.MajorVer=0;UBBBrowerInfo.MinorVer=0;
	};
	UBBBrowerInfo.IsIE55OrMore=UBBBrowerInfo.IsIE&&(UBBBrowerInfo.MajorVer>5||UBBBrowerInfo.MinorVer>=5);

var UBBScriptLoader=new Object();
UBBScriptLoader.IsLoading=false;
UBBScriptLoader.Queue=new Array();
UBBScriptLoader.AddScript=function(scriptPath){
	UBBScriptLoader.Queue[UBBScriptLoader.Queue.length]=scriptPath;
	//if (!this.IsLoading) this.CheckQueue();
	};
UBBScriptLoader.CheckQueue=function(){
	if (this.Queue.length>0){
		this.IsLoading=true;
		var sScriptPath=this.Queue[0];
		var oTempArray=new Array();
		for (i=1;i<this.Queue.length;i++) oTempArray[i-1]=this.Queue[i];
		this.Queue=oTempArray;
		var e;
		if (sScriptPath.lastIndexOf('.css')>0){
			 e=document.createElement('LINK');
			 e.rel='stylesheet';e.type='text/css';
			}
			else
			{
			 e=document.createElement("script");
			 e.type="text/javascript";
			 e.language="javascript";
			};
			document.getElementsByTagName("head")[0].appendChild(e);
var oEvent=function(){
	if (this.tagName=='LINK'||!this.readyState||this.readyState=='loaded') UBBScriptLoader.CheckQueue();};
	if (e.tagName=='LINK'){
		if (UBBBrowserInfo.IsIE) e.onload=oEvent;else UBBScriptLoader.CheckQueue();
		e.href=sScriptPath;
		}
		else{
		e.onload=e.onreadystatechange=oEvent;e.src=sScriptPath;
		};
	}
	else
	{
		this.IsLoading=false;
		if (this.OnEmpty) this.OnEmpty();};
	}


var UBBTextArea

//UBBBrowerInfo.IsIE �ж��Ƿ���IE
//UBBBrowerInfo.IsGecko �ж��Ƿ���Gecko
//���Ի�����

if (UBBBrowerInfo.IsIE){
 UBBScriptLoader.AddScript(strBestPath+'UBBCode_IE.js')
}

if (UBBBrowerInfo.IsGecko){
 UBBScriptLoader.AddScript(strBestPath+'UBBCode_Gecko.js')
}
UBBScriptLoader.CheckQueue();

function sizeChange(num,objname) {
	var obj=document.getElementById(objname)
	if (parseInt(obj.style.height)+num>=200) {
		obj.style.height = parseInt(obj.style.height) + num;	
	}
}

//���´���
function popnew(url,title,width,height){
    var w = 1024;
    var h = 768;

    if (document.all || document.layers){
        w = screen.availWidth;
        h = screen.availHeight;
    }

    var leftPos = (w/2-width/2);
    var topPos = (h/2.3-height/2.3);

    window.open(url,title,"width="+width+",height="+height+",top="+topPos+",left="+leftPos+",scrollbars=no,resizable=no,status=no")
}
/*function ctlent() {
	if((event.ctrlKey && window.event.keyCode == 13) || (event.altKey && window.event.keyCode == 83)) {
	  if (document.all.InstanceName.value.length>0) SubmitMsg();
	}
}*/