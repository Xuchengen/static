function checkform(){
	var form1=document.myform;
	try{
		if (GetContentLength()==0){
			alert("�������ݲ���Ϊ��!");
			return false;
		}
	}
	catch(e){
		if (form1.content.value=="") {
			alert("�������ݲ���Ϊ��!");
			form1.content.focus();
			return false;
		}
	}

	try{
		if (form1.username.value==""){
			alert("�û����Ʋ���Ϊ�գ�");
			form1.username.focus();
			return false;
		}
	}
	catch(e){}
	
	try{
		if (form1.codestr.value==""){
			alert("��������֤�룡");
			form1.codestr.focus();
			return false;
		}
	}
	catch(e){}

	try{
		if (form1.topic.value==""){
			alert("�������ⲻ��Ϊ�գ�");
			form1.topic.focus();
			return false;
		}
	}
	catch(e){}

	try{
		if ((form1.GuestEmail.value.indexOf("@") == -1) || (form1.GuestEmail.value.indexOf(".") == -1)){
			alert("��鿴����E-mail��ַ�Ƿ���ȷ������¼��!");
			form1.GuestEmail.focus();
       		return false;
		}
	}
	catch(e){}
}

function formatbt()
{
  var arr = showModalDialog("../editor/btformat.htm?",null, "dialogWidth:250pt;dialogHeight:166pt;toolbar=no;location=no;directories=no;status=no;menubar=NO;scrollbars=no;resizable=no;help=0; status:0");
  if (arr != null){
     document.myform.Topicformat.value=arr;
     myt.innerHTML="<span style='background-color: #FFFFff;font-size:12px' "+arr+">���ñ�����ʽ ABCdef</span>";
  }
}
function Cancelform()
{
  document.myform.Topicformat.value='';
  myt.innerHTML="<span style='background-color: #FFFFff;font-size:12px'>���ñ�����ʽ ABCdef</span>";
}
function CtrlEnter()
{
	if(event.ctrlKey && window.event.keyCode==13)
	{
		this.document.myform.submit();
	}	
}

function GetContentLength(){
	var oEditor = FCKeditorAPI.GetInstance('content') ;
	var oDOM = oEditor.EditorDocument ;
	var iLength ;

	if ( document.all )
	{
		iLength = oDOM.body.innerText.length ;
	}
	else
	{
		var r = oDOM.createRange() ;
		r.selectNodeContents( oDOM.body ) ;
		iLength = r.toString().length ;
	}
	return iLength
}

function CheckLength(){
	var strLen=0;
	try{
		strLen=GetContentLength();
	}
	catch(e){
		strLen=document.myform.content.value.length;
	}
	alert("\n������������ "+strLen+" �ֽ�");
}