tinyMCE.addI18n('zh-cn.remoteupload',{
	desc : '\u4FDD\u5B58\u8FDC\u7A0B\u56FE\u7247'
});
