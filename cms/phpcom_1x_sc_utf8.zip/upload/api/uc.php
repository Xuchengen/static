<?php

/**
 * Copyright (c) 2010-2011  phpcom.cn - All rights reserved.
 * Our Website : www.phpcom.cn www.phpcom.net www.cnxinyun.com
 * Description : This software is the proprietary information of phpcom.cn.
 * This File   : uc.php    2011-12-26
 */
error_reporting(0);
define('CURRENT_SCRIPT', 'api');
define('UCENTER_VERSION', '1.0.0');
define('UCENTER_RELEASE', '20111208');
define('API_SYNCLOGIN', 1);
define('API_SYNCLOGOUT', 1);

function synclogin(){
    return null;
}
?>
