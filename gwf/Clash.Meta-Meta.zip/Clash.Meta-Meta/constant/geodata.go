package constant

var (
	GeodataMode bool
	GeoIpUrl    string
	MmdbUrl     string
	GeoSiteUrl  string
)
