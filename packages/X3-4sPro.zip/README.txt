一、需要更改的配置文件以及脚本
1.Clash配置需要更改
2.Frpc配置需要更改
3.Java脚本需要更改
4.boot脚本需要更改
5.ttyd脚本需要更改

以上需要更改的地方做了"<>"标记，按照自己的需求做更改即可。

二、关于dropbear Key
目录中已经提供了一个Key文件，如果你比较膈应就自己生成一个吧
./dropbearmulti dropbearkey -t rsa -f key -s 2048

三、关于filebrowser配置
请执行以下命令更改

./filebrowser -d ./filebrowser.db config init
./filebrowser -d ./filebrowser.db config set --address 0.0.0.0
./filebrowser -d ./filebrowser.db config set --port 8088
./filebrowser -d ./filebrowser.db config set --locale zh-cn
./filebrowser -d ./filebrowser.db config set --root <目录，假设“/”>
./filebrowser -d ./filebrowser.db users add <用户名> <密码> --perm.admin

四、关于Clash cache.db文件
由于jffs2文件系统不支持对DB文件的写操作，在当前X3-4sPro光猫中有且仅有/tmp/目录等tmpfs文件系统支持读写。
当服务第一次启动时在/tmp/clash目录中生成cache.db文件，然后我们通过浏览器访问http://192.168.1.1:9090/ui
配置好节点信息后将cache.db写回到clash的config目录中。当下次启动clash时脚本会将config目录整体复制到/tmp/clash目录中，
然后直接读取cache.db文件。基于此咱们就解决了每次启动都需要手动设置一次节点配置的问题。

