#!/bin/sh

V_SHELL=dropbear.sh
V_CURRENT_PID=$$
V_PATH=/usr/data/scripts/bin/dropbear

for pid in `ps aux | grep "$V_SHELL" | grep -v "grep" | awk '{print $1}'`; do
    if [ "$pid" -ne "$V_CURRENT_PID" ]; then
        $(kill -9 "$pid" > /dev/null 2>&1)
    fi
done

while true; do
    local V_PROC=`ps aux | grep "$V_PATH/dropbearmulti dropbear -p 22 -r $V_PATH/key" | grep -v grep`
    if [ ! -n "$V_PROC" ]; then
        $(nohup "$V_PATH"/dropbearmulti dropbear -p 22 -r "$V_PATH"/key > /dev/null 2>&1 &)
    fi
    sleep 120
done

exit
