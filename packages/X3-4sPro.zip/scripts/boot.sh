#!/bin/sh

########################
#                      #
#      boot shell      #
#                      #
########################

# 指定GO程序根证书
export SSL_CERT_FILE=/etc/cacert.pem

# 内核参数
sysctl -w net.ipv4.ip_forward=1
sysctl -w net.ipv4.fwmark_reflect=1
sysctl -w net.ipv6.conf.all.disable_ipv6=1

# 修改密码
nohup `passwd << EOF
<新root密码>
<确认新root密码>
EOF` > /dev/null 2>&1 &

# 等待120秒开始引导脚本
sleep 120

# 杀进程
kill -9 `ps aux | grep cpulimit | grep -v grep | awk '{print $1}'`
kill -9 `ps aux | grep phoneapp | grep -v grep | awk '{print $1}'`

# 定时任务
$(crond -c /usr/data/scripts/cron/)

# FRPC服务
/usr/data/scripts/frpc.sh &

# Dropbear服务
$(nohup mount devpts /dev/pts -t devpts > /dev/null 2>&1 &)
/usr/data/scripts/dropbear.sh &

# ttyd服务
/usr/data/scripts/ttyd.sh &

# filebrowser服务
/usr/data/scripts/filebrowser.sh &

# mosdns服务
/usr/data/scripts/mosdns.sh &

# Clash服务
/usr/data/scripts/clash.sh &

exit