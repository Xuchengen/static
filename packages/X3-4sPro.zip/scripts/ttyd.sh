#!/bin/sh

V_SHELL=ttyd.sh
V_CURRENT_PID=$$
V_PATH=/usr/data/scripts/bin/ttyd

for pid in `ps aux | grep "$V_SHELL" | grep -v "grep" | awk '{print $1}'`; do
    if [ "$pid" -ne "$V_CURRENT_PID" ]; then
        $(kill -9 "$pid" > /dev/null 2>&1)
    fi
done

while true; do
    local V_PROC=`ps aux | grep "$V_PATH/ttyd -W -c" | grep -v grep`
    if [ ! -n "$V_PROC" ]; then
        $(nohup "$V_PATH"/ttyd -W -c <用户名>:<密码> -p 9999 /bin/login > /dev/null 2>&1 &)
    fi
    sleep 120
done

exit
