#!/bin/sh

# 指定GO程序根证书
export SSL_CERT_FILE=/etc/cacert.pem

V_SHELL=frpc.sh
V_CURRENT_PID=$$
V_PATH=/usr/data/scripts/bin/frpc

for pid in `ps aux | grep "$V_SHELL" | grep -v "grep" | awk '{print $1}'`; do
    if [ "$pid" -ne "$V_CURRENT_PID" ]; then
        $(kill -9 "$pid" > /dev/null 2>&1)
    fi
done

while true; do
    local V_PROC=`ps aux | grep "$V_PATH/frpc -c $V_PATH/frpc.ini" | grep -v grep`
    if [ ! -n "$V_PROC" ]; then
        $(nohup "$V_PATH"/frpc -c "$V_PATH"/frpc.ini > /dev/null 2>&1 &)
    fi
    sleep 120
done

exit
