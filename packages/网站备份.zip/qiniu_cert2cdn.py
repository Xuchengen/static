import uuid

import qiniu
from qiniu import DomainManager

# 替换为你的七牛云Access Key和Secret Key
access_key = 'qJJtEhhOrJXx4YouS4gNrMlGYfgCn9q_n9z_sxUI'
secret_key = 'doqJ2zkO-7gAqqCSryI7wchofSdl0GiqBTjG-qMI'

# 域名
cert_domain_name = 'xuchengen.cn'
target_domain_name = 'blog.xuchengen.cn'

# 证书
cert_pri_file_path = '/etc/letsencrypt/live/{}/privkey.pem'.format(cert_domain_name)
cert_ca_file_path = '/etc/letsencrypt/live/{}/fullchain.pem'.format(cert_domain_name)

# 构建鉴权对象
auth = qiniu.Auth(access_key, secret_key)

# 构建域名对象
domain_manager = DomainManager(auth)


# 获取文件内容
def get_file_content(file_path):
    with open(file_path, 'r') as cert_file:
        return cert_file.read()


if __name__ == '__main__':
    res, info = domain_manager.create_sslcert(str(uuid.uuid4()),
                                              cert_domain_name,
                                              get_file_content(cert_pri_file_path),
                                              get_file_content(cert_ca_file_path))

    if info.status_code != 200:
        raise Exception('SSL证书上传失败')

    print("SSL证书上传成功")
    cert_id = res['certID']

    res, info = domain_manager.put_httpsconf(target_domain_name, cert_id, True)

    if info.status_code != 200:
        raise Exception('部署SSL证书失败')

    print("部署SSL证书成功")
